//Demonstration od do-while loop
public class prog_25 
{
    public static void main(String[] args)
    {
        int a=0;
        while(a<5)
        {
            System.out.println(a+"\n");a++;
        }
        int b=10;
        do
        {
            System.out.println(b);
            b++;
        }while(b<10);
        int c=1;
        do
        {
            System.out.println(c);
            c++; 
        }while(c<=3);
    }    
}
