//Array reverse
public class prog_32 
{
    public static void main(String[] args)
    {
        int []marks={95,74,98,89,92};
        for(int i=marks.length-1;i>=0;System.out.println(marks[i--]));
    }
}
