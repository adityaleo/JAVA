//Demonstration of for each loop
public class prog_37 
{
    public static void main(String args[])
    {
        //declaring an array
        int arr[]={1,2,3,3,4,5};
        //traversing the array with for-each loop
        for (int i:arr)
            System.out.println(i);
    }
}
