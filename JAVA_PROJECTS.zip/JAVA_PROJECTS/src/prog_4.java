//NULL printing
public class prog_4 
{
    public static void main(String[] args) 
    {
        String line = null;
        System.out.println(line); 
    }
}
