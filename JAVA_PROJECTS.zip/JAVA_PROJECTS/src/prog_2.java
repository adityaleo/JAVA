//Double datatype
public class prog_2 
{
    public static void main(String[] args) 
    {
        
        float radius1 = 0.000000000056f;
        System.out.println(radius1);
        double radius=0.000456;
        System.out.println(radius);
    }
    
}
