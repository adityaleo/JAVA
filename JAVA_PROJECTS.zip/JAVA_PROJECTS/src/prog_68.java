//Demonstration  of sample user defined package
public class prog_68 
{
    public static void main(String[] args)
     {
        System.out.println("This is User defined Package");
     }   
}
