//While loop
public class prog_22 
{
    public static void main(String[] args)  
    {
        System.out.println("1");
        System.out.println("2");
        System.out.println("3");
        System.out.println("4");
        int i =100;
        while(i<=150)
        {
            System.out.print(i+" ");
            i++;
        }
    }  
}
