//Demonstration of for loop
public class prog_27 
{
    public static void main(String[] args)
    {
        for(int i=0;i<10;System.out.print((i++) +" "));
        int n =5;
        for(int i=0;i<n;System.out.print(2*(i++) +1 +" "));
        for(int i=5;i!= 0;System.out.print(i-- +" "));
    }    
}
