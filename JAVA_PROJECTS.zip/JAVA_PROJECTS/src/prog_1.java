//Float datatype
public class prog_1
{
    public static void main(String[] args)
    {
        float radius=8.56f;
        System.out.println(radius);
    }
    
}
