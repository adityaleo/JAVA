//Printing a letter , char equivalent to ascii and a no.
public class prog_3 {
    public static void main(String[] args) 
    {
        char letter='A';
        char num_as_text='6';
        char number=65;
        System.out.println("Letter : "+letter+"\nNumber as text : "+num_as_text+"\nNumber : "+number);
    }
}
