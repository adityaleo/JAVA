//Increment / Decrement operator
public class prog_12 
{
    public static void main(String[] args)
    {
        byte x= 5;
        int y =6;
        Short z =8;
        int a = y + z;
        float b=6.54f + x;
        System.out.println(b + a);
        int i =56;
        int B = i++;
        int j =67;
        int c = ++j;
        System.out.println(B+c);
        System.out.println(i++);
        System.out.println(i);
        System.out.println(++i);
        System.out.println(i);
        int Y=7;
        System.out.println(++Y * 8);
        char ch = 'a';
        System.out.println(++ch);	 
    }
}
