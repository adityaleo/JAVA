//Printing name & sum of three no.s
public class prog_5_6 {
    public static void main(String[] args) 
    {
        int my1stnum = (10+5)+(10*2);
        int my2ndnum = 12;
        int my3ndnum = 6;
        int total = my1stnum+my2ndnum+my3ndnum;
        int mylastnum = 1000-total;
        System.out.println(my1stnum);
        System.out.println(my2ndnum);
        System.out.println(total);
        System.out.println(mylastnum);
    }   
}
